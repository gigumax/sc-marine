/* ============================================================
   allies.js — AI marine fireteam: formation follow + combat
   ============================================================ */

const PROMOTE_KILLS = 50;                // your zerg kills to take command

const Allies = {
  list: [],
  names: ['RAYNOR', 'DIAZ', 'HORNER'],
  accents: [0xffd24a, 0x4ad0ff, 0x6aff8a],
  // wedge slots behind the leader, in leader-local space {x, z}
  // (local -z is the facing direction, so +z trails behind)
  slots: [{ x: -2.4, z: 2.6 }, { x: 2.4, z: 2.6 }, { x: 0, z: 3.8 }],
};

/* who's calling the shots — Raynor until you're promoted (or he's down) */
function squadLeader() {
  if (Game.leader) return null;
  return Allies.list.find(a => a.leader && !a.dead) || null;
}

/* ---------- marine model (primitives) ---------- */
function buildMarineMesh(accent) {
  const g = new THREE.Group();
  const armor  = new THREE.MeshStandardMaterial({ color: 0x3d5a78, roughness: 0.55, metalness: 0.45 });
  const armorD = new THREE.MeshStandardMaterial({ color: 0x24344a, roughness: 0.7,  metalness: 0.35 });
  const joint  = new THREE.MeshStandardMaterial({ color: 0x141a24, roughness: 0.9 });
  const visor  = new THREE.MeshBasicMaterial({ color: accent });
  const gunM   = new THREE.MeshStandardMaterial({ color: 0x1c222c, roughness: 0.7, metalness: 0.5 });

  // legs — hip-pivot boxes for walk cycle
  const legs = [];
  for (const s of [-1, 1]) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.72, 0.24), armorD);
    leg.geometry = leg.geometry.clone();
    leg.geometry.translate(0, -0.34, 0);               // pivot at hip
    leg.position.set(s * 0.16, 0.78, 0);
    g.add(leg); legs.push(leg);
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.12, 0.3), joint);
    boot.position.set(s * 0.16, 0.06, 0.04);
    g.add(boot);
  }

  // torso — chunky CMC power armor
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.62, 0.36), armor);
  torso.position.y = 1.18;
  g.add(torso);
  const chest = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.3, 0.1), armorD);
  chest.position.set(0, 1.28, 0.22);
  g.add(chest);
  const belt = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.1, 0.34), joint);
  belt.position.y = 0.86;
  g.add(belt);

  // pauldrons — signature marine bulk
  const arms = [];
  for (const s of [-1, 1]) {
    const pad = new THREE.Mesh(new THREE.SphereGeometry(0.21, 8, 6), armor);
    pad.scale.set(1, 0.85, 1);
    pad.position.set(s * 0.4, 1.45, 0);
    g.add(pad);
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.5, 0.15), joint);
    arm.position.set(s * 0.34, 1.14, 0.06);
    arm.rotation.x = -0.5;
    g.add(arm); arms.push(arm);
  }

  // helmet + glowing visor (team accent color)
  const helm = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), armor);
  helm.scale.set(1, 1.05, 1.05);
  helm.position.y = 1.72;
  g.add(helm);
  const vis = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.07, 0.05), visor);
  vis.position.set(0, 1.72, 0.19);
  g.add(vis);
  // backpack vents
  const pack = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.34, 0.12), armorD);
  pack.position.set(0, 1.28, -0.24);
  g.add(pack);

  // gauss rifle held forward
  const gun = new THREE.Group();
  const gBody = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.12, 0.52), gunM);
  gun.add(gBody);
  const gBarrel = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.34, 6), armorD);
  gBarrel.rotation.x = Math.PI / 2; gBarrel.position.z = 0.4;
  gun.add(gBarrel);
  const gMag = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.14, 0.08), armorD);
  gMag.position.set(0, -0.12, -0.05);
  gun.add(gMag);
  gun.position.set(0.22, 1.24, 0.3);
  g.add(gun);

  // muzzle flash sprite at barrel tip
  const flash = new THREE.Sprite(new THREE.SpriteMaterial({
    color: 0xffd080, transparent: true, opacity: 0,
    blending: THREE.AdditiveBlending, depthWrite: false,
  }));
  flash.scale.set(0.3, 0.3, 0.3);
  flash.position.set(0, 0, 0.58);
  gun.add(flash);

  // overhead health bar — bg + fg sprites
  const barBg = new THREE.Sprite(new THREE.SpriteMaterial({
    color: 0x180c0c, transparent: true, opacity: 0.75, depthWrite: false,
  }));
  barBg.scale.set(0.95, 0.09, 1); barBg.position.y = 2.12;
  g.add(barBg);
  const barFg = new THREE.Sprite(new THREE.SpriteMaterial({
    color: 0x5aff8a, transparent: true, opacity: 0.95, depthWrite: false,
  }));
  barFg.scale.set(0.9, 0.06, 1); barFg.position.y = 2.12;
  g.add(barFg);

  g.userData.legs = legs;
  g.userData.flash = flash;
  g.userData.barFg = barFg;
  g.userData.barBg = barBg;
  return g;
}

/* ---------- squad lifecycle ---------- */
function spawnAllies() {
  clearAllies();
  for (let i = 0; i < 3; i++) {
    const mesh = buildMarineMesh(Allies.accents[i]);
    // spawn in the wedge behind the player's facing dir
    const sl = Allies.slots[i];
    const sin = Math.sin(Player.yaw), cos = Math.cos(Player.yaw);
    const wx = sl.x * cos + sl.z * sin;
    const wz = -sl.x * sin + sl.z * cos;
    mesh.position.set(Player.pos.x + wx, 0, Player.pos.z + wz);
    mesh.rotation.y = Player.yaw;
    Enemies.scene.add(mesh);
    Allies.list.push({
      mesh, pos: mesh.position,
      idx: i,
      name: Allies.names[i],
      accent: '#' + Allies.accents[i].toString(16).padStart(6, '0'),
      leader: i === 0,
      hp: i === 0 ? 150 : 90, maxHp: i === 0 ? 150 : 90,
      yaw: Player.yaw,
      dead: false, gone: false, deathT: 0,
      fireT: 0.4 + i * 0.15, retargetT: i * 0.12,
      tgt: null, tgtHive: null,
      slot: sl,
      walkT: Math.random() * 7,
      regenT: 0, hurtT: 0,
      radius: 0.55,
    });
  }
  buildSquadHud();
}

function clearAllies() {
  for (const a of Allies.list) Enemies.scene.remove(a.mesh);
  Allies.list = [];
  const sq = document.getElementById('squad');
  if (sq) sq.innerHTML = '';
}

/* ---------- squad HUD chips ---------- */
function buildSquadHud() {
  const sq = document.getElementById('squad');
  if (!sq) return;
  sq.innerHTML = Allies.list.map((a, i) =>
    `<div class="chip" id="chip${i}"><b style="color:${a.accent}">${a.leader && !Game.leader ? '★ ' : ''}${a.name}</b><i><u></u></i></div>`
  ).join('') + (Game.leader
    ? '<div class="chip you" id="chipYou"><b>★ YOU</b><i><u></u></i></div>' : '');
}
function updateSquadHud() {
  for (const a of Allies.list) {
    const chip = document.getElementById('chip' + a.idx);
    if (!chip) continue;
    chip.classList.toggle('dead', a.dead);
    const f = chip.querySelector('u');
    f.style.width = Math.max(0, a.hp / a.maxHp * 100) + '%';
    f.className = a.hp > a.maxHp * 0.5 ? '' : a.hp > a.maxHp * 0.25 ? 'warn' : 'crit';
  }
  const you = document.getElementById('chipYou');
  if (you) {
    const f = you.querySelector('u');
    f.style.width = Math.max(0, Player.hp) + '%';
    f.className = Player.hp > 50 ? '' : Player.hp > 25 ? 'warn' : 'crit';
  }
}

/* ---------- promotion: 50 kills → you take command ---------- */
function promoteToLeader() {
  Game.leader = true;
  UI.waveBanner('PROMOTED — SQUAD LEADER');
  UI.toast('RAYNOR: "You\'ve got command. Push the hives!"');
  Audio2.pickup();
  buildSquadHud();
}

/* ---------- damage ---------- */
function damageAlly(a, dmg, fromPos) {
  if (a.dead) return;
  a.hp -= dmg;
  a.regenT = 6;
  a.hurtT = 0.18;
  bloodBurst(a.pos.clone().add(new THREE.Vector3(0, 1.1, 0)), 4);
  Audio2.hitAt(a.pos.distanceTo(Player.pos));
  if (a.hp <= 0) {
    a.hp = 0; a.dead = true; a.deathT = 0;
    a.mesh.userData.barBg.visible = false;
    a.mesh.userData.barFg.visible = false;
    UI.toast('☠ ' + a.name + ' IS DOWN' + (a.leader && !Game.leader ? ' — TAKE POINT' : ''));
    Audio2.kill(a.pos.distanceTo(Player.pos));
    gibBurst(a.pos.clone().add(new THREE.Vector3(0, 0.8, 0)), false);
  }
}

/* ---------- shooting ---------- */
const _aaim = new THREE.Vector3();

function allyShoot(a) {
  const tgtE = a.tgt, tgtH = a.tgtHive;
  const aim = tgtE
    ? _aaim.set(tgtE.mesh.position.x, tgtE.mesh.position.y + 0.55, tgtE.mesh.position.z)
    : _aaim.copy(tgtH.pos).setY(0.7);
  const dist = a.pos.distanceTo(aim);

  // muzzle flash + sound
  const fl = a.mesh.userData.flash;
  fl.material.opacity = 1; fl.material.rotation = Math.random() * 7;
  Audio2.shotAt(dist > 0 ? a.pos.distanceTo(Player.pos) : 1);

  // accuracy falls off with range; jitter while moving
  const acc = Math.max(0.12, 0.62 - dist * 0.015 - (a.moving ? 0.18 : 0));
  const hit = Math.random() < acc;
  let end = aim.clone();
  if (!hit) end.add(new THREE.Vector3(
    (Math.random() - .5) * dist * 0.13,
    (Math.random() - .5) * dist * 0.09,
    (Math.random() - .5) * dist * 0.13));
  if (hit) {
    if (tgtE) damageEnemy(tgtE, 11, false);
    else if (tgtH) damageSpawner(tgtH, 9);
  }
  // tracer from rifle tip
  const from = a.pos.clone(); from.y = 1.3;
  from.x += Math.sin(a.yaw) * 0.55; from.z += Math.cos(a.yaw) * 0.55;
  spawnTracer(from, end);
}

/* ---------- per-frame squad update ---------- */
function updateAllies(dt) {
  const pp = Player.pos;
  const lead = squadLeader();
  const anchor = lead ? lead.pos : pp;             // formation anchor: Raynor, else you
  const anchorYaw = lead ? lead.yaw : Player.yaw;
  for (const a of Allies.list) {
    const m = a.mesh;

    if (a.dead) {
      a.deathT += dt;
      m.rotation.x = Math.min(Math.PI / 2, a.deathT * 5);
      if (a.deathT > 4) m.position.y = -(a.deathT - 4) * 0.4;   // sink away
      if (a.deathT > 6.5) { Enemies.scene.remove(m); a.gone = true; }
      continue;
    }

    a.fireT -= dt;
    a.retargetT -= dt;
    if (a.hurtT > 0) a.hurtT -= dt;
    if (a.regenT > 0) a.regenT -= dt;
    else if (a.hp < a.maxHp) a.hp = Math.min(a.maxHp, a.hp + 4.5 * dt);

    /* --- pick target: nearest live zerg, else nearest live hive --- */
    if (a.retargetT <= 0) {
      a.retargetT = 0.35;
      a.tgt = null; a.tgtHive = null;
      let best = 34;
      for (const e of Enemies.list) {
        if (e.dead) continue;
        const d = Math.hypot(e.mesh.position.x - a.pos.x, e.mesh.position.z - a.pos.z);
        if (d < best) { best = d; a.tgt = e; }
      }
      if (!a.tgt) {
        best = 30;
        for (const s of World.spawners) {
          if (s.dead) continue;
          const d = Math.hypot(s.pos.x - a.pos.x, s.pos.z - a.pos.z);
          if (d < best) { best = d; a.tgtHive = s; }
        }
      }
    }
    if (a.tgt && a.tgt.dead) a.tgt = null;
    if (a.tgtHive && a.tgtHive.dead) a.tgtHive = null;

    /* --- move: leader pushes the objective, followers hold formation --- */
    a.moving = false;
    let sdx = 0, sdz = 0;                              // desired-dir (facing fallback)
    if (a === lead) {
      // Raynor: advance on the nearest live hive, leashed to the player
      const goal = a.tgtHive ? a.tgtHive.pos : pp;
      sdx = goal.x - a.pos.x; sdz = goal.z - a.pos.z;
      const gapP = Math.hypot(pp.x - a.pos.x, pp.z - a.pos.z);
      if (gapP > 15) { sdx = pp.x - a.pos.x; sdz = pp.z - a.pos.z; }
      const gd = Math.hypot(sdx, sdz);
      const holdR = a.tgtHive ? 7 : 2.4;               // stand off the hive, tight on you
      if (gd > holdR) {
        const sp = gd > 10 ? 9.0 : 6.0;
        const res = worldCollide(a.pos.x + sdx / gd * sp * dt,
                                 a.pos.z + sdz / gd * sp * dt, a.radius);
        a.pos.x = res.x; a.pos.z = res.z;
        a.moving = true;
        a.walkT += dt * sp * 1.5;
      }
    } else {
      // follower: wedge slot behind the anchor (Raynor → later you)
      const sin = Math.sin(anchorYaw), cos = Math.cos(anchorYaw);
      const sx = anchor.x + a.slot.x * cos + a.slot.z * sin;
      const sz = anchor.z - a.slot.x * sin + a.slot.z * cos;
      sdx = sx - a.pos.x; sdz = sz - a.pos.z;
      const slotDist = Math.hypot(sdx, sdz);

      // hold ground & shoot if a target is close and we're near our slot
      const engaged = a.tgt && Math.hypot(a.tgt.mesh.position.x - a.pos.x,
                                          a.tgt.mesh.position.z - a.pos.z) < 15;
      if (slotDist > (engaged && slotDist < 7 ? 7 : 0.9)) {
        const sp = slotDist > 10 ? 9.0 : 6.0;             // sprint to catch up
        const res = worldCollide(a.pos.x + sdx / slotDist * sp * dt,
                                 a.pos.z + sdz / slotDist * sp * dt, a.radius);
        a.pos.x = res.x; a.pos.z = res.z;
        a.moving = true;
        a.walkT += dt * sp * 1.5;
      }
    }

    // separation: player, squadmates, zerg
    const sep = (ox, oz, min) => {
      const dx = a.pos.x - ox, dz = a.pos.z - oz;
      const d = Math.hypot(dx, dz);
      if (d > 0 && d < min) { a.pos.x += dx / d * (min - d) * 0.5; a.pos.z += dz / d * (min - d) * 0.5; }
    };
    sep(pp.x, pp.z, 1.3);
    for (const o of Allies.list) if (o !== a && !o.dead) sep(o.pos.x, o.pos.z, 1.3);
    for (const e of Enemies.list) if (!e.dead) sep(e.mesh.position.x, e.mesh.position.z, e.radius + a.radius);

    /* --- facing: target > move dir > player --- */
    let wantYaw;
    const aimAt = a.tgt ? a.tgt.mesh.position : a.tgtHive ? a.tgtHive.pos : null;
    if (aimAt) wantYaw = Math.atan2(aimAt.x - a.pos.x, aimAt.z - a.pos.z);
    else if (a.moving) wantYaw = Math.atan2(sdx, sdz);
    else wantYaw = anchorYaw;
    let dy = wantYaw - a.yaw;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;
    a.yaw += dy * Math.min(1, dt * 10);
    m.rotation.y = a.yaw;

    /* --- fire --- */
    if (a.fireT <= 0 && aimAt && Math.abs(dy) < 0.35) {
      const d = Math.hypot(aimAt.x - a.pos.x, aimAt.z - a.pos.z);
      if (d < 34) { allyShoot(a); a.fireT = 0.17 + Math.random() * 0.06; }
    }

    /* --- animation --- */
    const legs = m.userData.legs;
    if (a.moving) {
      legs[0].rotation.x = Math.sin(a.walkT) * 0.7;
      legs[1].rotation.x = Math.sin(a.walkT + Math.PI) * 0.7;
      m.position.y = Math.abs(Math.sin(a.walkT)) * 0.05;
    } else {
      legs[0].rotation.x *= 1 - Math.min(1, dt * 10);
      legs[1].rotation.x *= 1 - Math.min(1, dt * 10);
      m.position.y = 0;
    }
    // hurt flash — red tint on armor
    m.traverse(o => {
      if (o.isMesh && o.material.emissive)
        o.material.emissive.setHex(a.hurtT > 0 ? 0x601008 : 0x000000);
    });
    const fl = m.userData.flash;
    if (fl.material.opacity > 0) fl.material.opacity -= dt * 16;
    // health bar
    const frac = Math.max(0, a.hp / a.maxHp);
    const bar = m.userData.barFg;
    bar.scale.x = 0.9 * frac;
    bar.position.x = -0.45 * (1 - frac);                // left-align shrink
    bar.material.color.setHex(frac > 0.5 ? 0x5aff8a : frac > 0.25 ? 0xffd94a : 0xff5a4a);
  }
  Allies.list = Allies.list.filter(a => !a.gone);
}

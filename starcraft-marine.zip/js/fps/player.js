/* ============================================================
   player.js — marine: FPS controls, rifle, shooting, vitals
   ============================================================ */

const Player = {
  pos: new THREE.Vector3(0, 0, 0),       // feet position
  vel: new THREE.Vector3(),
  yaw: 0, pitch: 0,
  eyeH: 1.62,
  hp: 100, maxHp: 100,
  mag: 32, magSize: 32, reserve: 320,
  reloading: false, reloadT: 0,
  fireT: 0, firing: false, aiming: false,
  firingMouse: false, aimingMouse: false,
  dead: false,
  kills: 0,                          // your zerg kills → 50 earns command
  regenT: 0,
  bobT: 0, stepT: 0,
  recoil: 0,
  shake: 0,
  grounded: true,
  cam: null, gun: null, muzzle: null, muzzleLight: null,
  tracers: [], impacts: [],
};

const EYE = () => Player.pos.y + Player.eyeH;

/* ---------- rifle viewmodel ---------- */
function buildGun(camera) {
  const g = new THREE.Group();
  const metal = new THREE.MeshStandardMaterial({ color: 0x3a4552, roughness: 0.5, metalness: 0.7 });
  const dark  = new THREE.MeshStandardMaterial({ color: 0x1c222c, roughness: 0.7, metalness: 0.4 });
  const glow  = new THREE.MeshBasicMaterial({ color: 0x4ad0ff });

  const body = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.13, 0.5), metal);
  g.add(body);
  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.42, 8), dark);
  barrel.rotation.x = Math.PI / 2; barrel.position.set(0, 0.02, -0.42);
  g.add(barrel);
  const mag = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.16, 0.1), dark);
  mag.position.set(0, -0.13, 0.05); mag.rotation.x = 0.25;
  g.add(mag);
  const stock = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.1, 0.2), dark);
  stock.position.set(0, -0.01, 0.32);
  g.add(stock);
  const sight = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.05, 0.06), metal);
  sight.position.set(0, 0.095, -0.1);
  g.add(sight);
  const dot = new THREE.Mesh(new THREE.SphereGeometry(0.008, 6, 5), glow);
  dot.position.set(0, 0.115, -0.1);
  g.add(dot);
  // grip light strip (marine suit glow)
  const strip = new THREE.Mesh(new THREE.BoxGeometry(0.095, 0.015, 0.3), glow);
  strip.position.set(0, -0.045, -0.05);
  g.add(strip);

  // muzzle flash sprite + light
  const flashMat = new THREE.SpriteMaterial({
    color: 0xffd080, transparent: true, opacity: 0,
    blending: THREE.AdditiveBlending, depthWrite: false,
  });
  const flash = new THREE.Sprite(flashMat);
  flash.scale.set(0.35, 0.35, 0.35);
  flash.position.set(0, 0.02, -0.66);
  g.add(flash);
  Player.muzzle = flash;
  const ml = new THREE.PointLight(0xffb060, 0, 9);
  ml.position.set(0, 0.02, -0.7);
  g.add(ml);
  Player.muzzleLight = ml;

  g.position.set(0.26, -0.22, -0.45);
  camera.add(g);
  Player.gun = g;
}

/* ---------- init ---------- */
function initPlayer(camera) {
  Player.cam = camera;
  Player.pos.set(0, 0, 0);
  Player.yaw = Math.PI; Player.pitch = 0;
  Player.hp = 100; Player.mag = 32; Player.reserve = 320;
  Player.reloading = false; Player.dead = false;
  Player.recoil = 0; Player.shake = 0;
  buildGun(camera);

  // helmet flashlight
  const spot = new THREE.SpotLight(0xcfe8ff, 0.9, 40, 0.55, 0.4, 1);
  camera.add(spot);
  spot.position.set(0, 0.1, 0);
  const tgt = new THREE.Object3D();
  tgt.position.set(0, 0, -10);
  camera.add(tgt);
  spot.target = tgt;

  // mouselook
  document.addEventListener('mousemove', e => {
    if (document.pointerLockElement && !Player.dead) {
      Player.yaw   -= e.movementX * 0.0022;
      Player.pitch -= e.movementY * 0.0022;
      Player.pitch = Math.max(-1.45, Math.min(1.45, Player.pitch));
    }
  });
  document.addEventListener('mousedown', e => {
    if (!Game.running || Player.dead) return;
    if (e.button === 0) Player.firingMouse = true;
    if (e.button === 2) Player.aimingMouse = true;
  });
  document.addEventListener('mouseup', e => {
    if (e.button === 0) Player.firingMouse = false;
    if (e.button === 2) Player.aimingMouse = false;
  });
  document.addEventListener('keydown', e => {
    if (e.key.toLowerCase() === 'r') startReload();
    if (e.key === ' ') { e.preventDefault(); tryJump(); }
  });
  document.addEventListener('contextmenu', e => e.preventDefault());
}

/* ---------- movement ---------- */
const KEYS = {};
document.addEventListener('keydown', e => KEYS[e.key.toLowerCase()] = true);
document.addEventListener('keyup',   e => KEYS[e.key.toLowerCase()] = false);

function tryJump() {
  if (Player.grounded && !Player.dead) {
    Player.vel.y = 5.4;
    Player.grounded = false;
    Audio2.jump();
  }
}
function startReload() {
  if (Player.reloading || Player.mag === Player.magSize || Player.reserve <= 0 || Player.dead) return;
  Player.reloading = true; Player.reloadT = 1.5;
  Audio2.reload();
  document.getElementById('reload-hint').textContent = 'RELOADING';
}

function movePlayer(dt, moveX, moveZ, sprint) {
  // input dir in local space → world
  const sin = Math.sin(Player.yaw), cos = Math.cos(Player.yaw);
  let dx = moveX * cos + moveZ * sin;
  let dz = -moveX * sin + moveZ * cos;
  const len = Math.hypot(dx, dz);
  const speed = (sprint ? 9.2 : 6.0) * (Player.aiming ? 0.55 : 1);
  if (len > 0) { dx /= len; dz /= len; }

  const res = worldCollide(
    Player.pos.x + dx * speed * dt,
    Player.pos.z + dz * speed * dt,
    0.5
  );
  Player.pos.x = res.x; Player.pos.z = res.z;

  // gravity / jump
  Player.vel.y -= 16 * dt;
  Player.pos.y += Player.vel.y * dt;
  if (Player.pos.y <= 0) { Player.pos.y = 0; Player.vel.y = 0; Player.grounded = true; }

  // headbob + footsteps
  if (len > 0 && Player.grounded) {
    Player.bobT += dt * (sprint ? 11 : 8);
    Player.stepT -= dt;
    if (Player.stepT <= 0) { Player.stepT = sprint ? 0.28 : 0.4; Audio2.step(); }
  } else {
    Player.bobT *= 1 - Math.min(1, dt * 8);
  }

  // regen vitals after 5s no damage
  if (Player.regenT > 0) Player.regenT -= dt;
  else if (Player.hp < Player.maxHp) Player.hp = Math.min(Player.maxHp, Player.hp + 9 * dt);
}

/* ---------- shooting ---------- */
const _ray = new THREE.Raycaster();
const _dir = new THREE.Vector3();

function fireWeapon() {
  if (Player.mag <= 0) { Audio2.dry(); startReload(); return; }
  Player.mag--;
  Player.fireT = 1 / 9;                       // 9 rps auto
  Player.recoil = Math.min(1, Player.recoil + 0.55);
  Player.shake = Math.min(1, Player.shake + 0.3);
  Player.pitch += 0.006 + Math.random() * 0.004;
  Player.yaw   += (Math.random() - .5) * 0.004;

  // muzzle flash
  Player.muzzle.material.opacity = 1;
  Player.muzzle.material.rotation = Math.random() * 7;
  Player.muzzleLight.intensity = 2.2;

  Audio2.shot();

  // spread: tighter when aiming
  const spread = Player.aiming ? 0.004 : 0.017;
  _dir.set((Math.random() - .5) * spread * 2, (Math.random() - .5) * spread * 2, -1)
      .normalize().applyQuaternion(Player.cam.quaternion);
  _ray.set(Player.cam.getWorldPosition(new THREE.Vector3()), _dir);
  _ray.far = 120;

  const meshes = [];
  for (const e of Enemies.list) if (!e.dead) meshes.push(e.mesh);
  for (const s of World.spawners) if (!s.dead) meshes.push(s.mesh);
  const hits = _ray.intersectObjects(meshes, true);

  let end = _ray.ray.origin.clone().add(_dir.clone().multiplyScalar(80));
  if (hits.length) {
    const h = hits[0];
    end = h.point.clone();
    // walk up to the entity root
    let obj = h.object, en = null, sp = null, part = 'body';
    while (obj) {
      if (obj.userData.enemy) { en = obj.userData.enemy; break; }
      if (obj.userData.spawner) { sp = obj.userData.spawner; break; }
      if (obj.userData.part) part = obj.userData.part;
      obj = obj.parent;
    }
    if (en) {
      const head = part === 'head';
      damageEnemy(en, head ? 34 : 16, head, true);
    } else if (sp) {
      damageSpawner(sp, 16);
    }
  } else {
    // wall/ground spark — cheap test: ray vs ground plane
    const t = -_ray.ray.origin.y / _dir.y;
    if (_dir.y < 0 && t > 0 && t < 80) {
      end = _ray.ray.origin.clone().add(_dir.clone().multiplyScalar(t));
      sparkBurst(end);
    }
  }
  spawnTracer(Player.cam.getWorldPosition(new THREE.Vector3())
    .add(new THREE.Vector3(0.12, -0.08, 0).applyQuaternion(Player.cam.quaternion))
    .add(_dir.clone().multiplyScalar(0.9)), end);
}

function spawnTracer(from, to) {
  const geo = new THREE.BufferGeometry().setFromPoints([from, to]);
  const line = new THREE.Line(geo, new THREE.LineBasicMaterial({
    color: 0xffe8a0, transparent: true, opacity: 0.9,
  }));
  Enemies.scene.add(line);
  Player.tracers.push({ m: line, t: 0, ttl: 0.07 });
}

const _sparkGeo = new THREE.SphereGeometry(0.03, 4, 3);
const _sparkMat = new THREE.MeshBasicMaterial({ color: 0xffc060 });
function sparkBurst(pos) {
  for (let i = 0; i < 4; i++) {
    const m = new THREE.Mesh(_sparkGeo, _sparkMat);
    m.position.copy(pos);
    Enemies.scene.add(m);
    Enemies.gibs.push({
      m, ttl: 0.25, t: 0,
      vx: (Math.random() - .5) * 4, vy: 1 + Math.random() * 2, vz: (Math.random() - .5) * 4, rs: 0,
    });
  }
}

function updateTracers(dt) {
  for (const t of Player.tracers) {
    t.t += dt;
    t.m.material.opacity = 0.9 * (1 - t.t / t.ttl);
    if (t.t > t.ttl) { Enemies.scene.remove(t.m); t.done = true; }
  }
  Player.tracers = Player.tracers.filter(t => !t.done);
}

/* ---------- damage ---------- */
function damagePlayer(dmg, fromPos) {
  if (Player.dead) return;
  Player.hp -= dmg;
  Player.regenT = 5;
  Player.shake = Math.min(1.6, Player.shake + 0.8);
  Audio2.hurt();
  UI.damageFlash();
  if (Player.hp <= 0) {
    Player.hp = 0;
    Player.dead = true;
    Game.gameOver();
  }
}
Player.heal = function (n) {
  this.hp = Math.min(this.maxHp, this.hp + n);
  const hf = document.getElementById('heal-flash');
  hf.style.opacity = 1; setTimeout(() => hf.style.opacity = 0, 60);
};

/* ---------- per-frame ---------- */
function updatePlayer(dt) {
  // fire / reload timers
  if (Player.fireT > 0) Player.fireT -= dt;
  if (Player.reloading) {
    Player.reloadT -= dt;
    if (Player.reloadT <= 0) {
      const need = Player.magSize - Player.mag;
      const take = Math.min(need, Player.reserve);
      Player.mag += take; Player.reserve -= take;
      Player.reloading = false;
      document.getElementById('reload-hint').textContent = '';
    }
  }
  if (Player.firing && Player.fireT <= 0 && !Player.reloading && !Player.dead) fireWeapon();
  if (Player.mag === 0 && !Player.reloading && Player.reserve > 0) startReload();

  // recoil & shake decay
  Player.recoil = Math.max(0, Player.recoil - dt * 5);
  Player.shake  = Math.max(0, Player.shake  - dt * 4);
  if (Player.muzzle.material.opacity > 0) Player.muzzle.material.opacity -= dt * 14;
  if (Player.muzzleLight.intensity > 0)  Player.muzzleLight.intensity -= dt * 30;

  updateTracers(dt);

  // camera transform: pos + yaw/pitch + bob + shake
  const bobY = Math.sin(Player.bobT * 2) * 0.03;
  const bobX = Math.cos(Player.bobT) * 0.02;
  const sx = (Math.random() - .5) * Player.shake * 0.05;
  const sy = (Math.random() - .5) * Player.shake * 0.05;
  Player.cam.position.set(Player.pos.x + bobX, EYE() + bobY, Player.pos.z);
  Player.cam.rotation.order = 'YXZ';
  Player.cam.rotation.y = Player.yaw;
  Player.cam.rotation.x = Player.pitch + Player.recoil * 0.03 + sx;
  Player.cam.rotation.z = sy * 0.5;

  // FOV: aim zoom
  const targetFov = Player.aiming ? 52 : 75;
  if (Math.abs(Player.cam.fov - targetFov) > 0.5) {
    Player.cam.fov += (targetFov - Player.cam.fov) * Math.min(1, dt * 12);
    Player.cam.updateProjectionMatrix();
  }
  document.getElementById('crosshair').classList.toggle('aim', Player.aiming);

  // gun sway + recoil kick
  const g = Player.gun;
  g.position.z = -0.45 + Player.recoil * 0.07;
  g.position.x = 0.26 + Math.cos(Player.bobT) * 0.008 - (Player.aiming ? 0.26 : 0);
  g.position.y = -0.22 + Math.sin(Player.bobT * 2) * 0.006 + (Player.aiming ? 0.115 : 0);
  g.rotation.x = Player.reloading ? -0.7 : Player.recoil * 0.12;
}

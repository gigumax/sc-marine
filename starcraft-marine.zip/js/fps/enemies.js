/* ============================================================
   enemies.js — zergling meshes, chase/lunge AI, wave manager
   ============================================================ */

const Enemies = {
  list: [],
  scene: null,
  kills: 0,
  gibs: [],
  pickups: [],
  spits: [],                     // roach acid projectiles
};

/* ---------- zergling model (primitives) ---------- */
// veined membrane wing drawn once on a canvas — translucent insect look
let _wingTex = null;
function wingTexture() {
  if (_wingTex) return _wingTex;
  const c = document.createElement('canvas');
  c.width = 256; c.height = 160;
  const g = c.getContext('2d');
  // membrane fan: root at left edge, scalloped trailing edge right
  g.beginPath();
  g.moveTo(8, 80);
  g.quadraticCurveTo(70, 4, 252, 10);       // leading edge
  g.quadraticCurveTo(216, 52, 250, 68);     // scallop
  g.quadraticCurveTo(202, 88, 242, 110);
  g.quadraticCurveTo(182, 118, 212, 148);
  g.quadraticCurveTo(120, 152, 8, 80);      // trailing edge
  g.closePath();
  const mg = g.createLinearGradient(0, 0, 256, 0);
  mg.addColorStop(0, 'rgba(148,104,158,.95)');
  mg.addColorStop(1, 'rgba(214,196,204,.5)');
  g.fillStyle = mg; g.fill();
  // veins radiating from the wing root
  g.strokeStyle = 'rgba(88,42,108,.85)'; g.lineWidth = 3;
  for (const [tx, ty] of [[250, 12], [246, 66], [238, 108], [208, 146], [120, 150]]) {
    g.beginPath(); g.moveTo(8, 80);
    g.quadraticCurveTo(120, (80 + ty) / 2, tx, ty); g.stroke();
  }
  // thick leading-edge spar
  g.strokeStyle = 'rgba(66,32,86,.9)'; g.lineWidth = 6;
  g.beginPath(); g.moveTo(8, 80); g.quadraticCurveTo(70, 4, 252, 10); g.stroke();
  _wingTex = new THREE.CanvasTexture(c);
  return _wingTex;
}

// shared geometries/materials — one upload reused by every zergling
const _zgeo = {}, _zmats = {};
function zg(key, make) { return _zgeo[key] || (_zgeo[key] = make()); }
function zergMats(hunter) {
  const k = hunter ? 'h' : 'z';
  if (!_zmats[k]) _zmats[k] = {
    body: new THREE.MeshStandardMaterial({
      color: hunter ? 0x7c1620 : 0x6e2f52, roughness: 0.8,
    }),
    dark: new THREE.MeshStandardMaterial({
      color: hunter ? 0x2e0a10 : 0x33122a, roughness: 1,
    }),
    bone: new THREE.MeshStandardMaterial({ color: 0xd9c9a4, roughness: 0.55 }),
    eye:  new THREE.MeshBasicMaterial({ color: 0xffcc33 }),
    wing: new THREE.MeshBasicMaterial({
      map: wingTexture(), transparent: true, opacity: 0.95, alphaTest: 0.05,
      side: THREE.DoubleSide, depthWrite: false,
      color: hunter ? 0xffb0a0 : 0xffffff,
    }),
  };
  return _zmats[k];
}

// curved scythe-horn: tapering cone chain arcing up then forward (y-z plane)
function buildHorn(len, baseR, span, mat) {
  const g = new THREE.Group();
  const R = len / span, N = 6;
  for (let i = 0; i < N; i++) {
    const phi = (i + 0.5) / N * span;
    const r = Math.max(baseR * (1 - i / (N - 1) * 0.82), 0.02);
    const seg = new THREE.Mesh(
      zg('horn' + i, () => new THREE.ConeGeometry(r, len / N * 1.45, 5)), mat);
    seg.position.set(0, R * Math.sin(phi), R * (1 - Math.cos(phi)));
    seg.rotation.x = phi;
    g.add(seg);
  }
  return g;
}

function buildZerglingMesh(scale, hunter) {
  const g = new THREE.Group();
  const M = zergMats(hunter);

  // hunched torso — nose-down posture
  const body = new THREE.Mesh(
    zg('body', () => new THREE.SphereGeometry(0.5, 10, 8)), M.body);
  body.scale.set(0.9, 0.75, 1.3);
  body.position.set(0, 0.6, 0.05);
  body.rotation.x = 0.18;
  body.userData.part = 'body';
  g.add(body);

  // rear abdomen bulk
  const abd = new THREE.Mesh(
    zg('abd', () => new THREE.SphereGeometry(0.44, 9, 7)), M.body);
  abd.scale.set(0.85, 0.75, 1.0);
  abd.position.set(0, 0.72, -0.55);
  abd.userData.part = 'body';
  g.add(abd);

  // low forward head
  const head = new THREE.Mesh(
    zg('head', () => new THREE.SphereGeometry(0.27, 8, 7)), M.body);
  head.scale.set(0.95, 0.9, 1.15);
  head.position.set(0, 0.55, 0.66);
  head.userData.part = 'head';
  g.add(head);

  // skull crest sweeping back
  const crest = new THREE.Mesh(
    zg('crest', () => new THREE.ConeGeometry(0.1, 0.5, 5)), M.dark);
  crest.rotation.x = -Math.PI / 2 + 0.5;
  crest.position.set(0, 0.72, 0.5);
  g.add(crest);

  // wide jaw + bone fangs
  const jaw = new THREE.Mesh(
    zg('jaw', () => new THREE.ConeGeometry(0.18, 0.45, 5)), M.dark);
  jaw.rotation.x = Math.PI / 2 + 0.55;
  jaw.position.set(0, 0.44, 0.88);
  jaw.userData.part = 'head';
  g.add(jaw);
  for (const s of [-1, 1]) {
    const fang = new THREE.Mesh(
      zg('fang', () => new THREE.ConeGeometry(0.028, 0.16, 4)), M.bone);
    fang.rotation.x = Math.PI * 0.85;
    fang.position.set(s * 0.09, 0.5, 0.86);
    fang.userData.part = 'head';
    g.add(fang);
    const fang2 = new THREE.Mesh(
      zg('fang', () => new THREE.ConeGeometry(0.028, 0.16, 4)), M.bone);
    fang2.rotation.x = Math.PI * 0.85;
    fang2.position.set(s * 0.15, 0.46, 0.74);
    fang2.userData.part = 'head';
    g.add(fang2);
  }

  // twin eye pairs
  for (const s of [-1, 1]) {
    const eye = new THREE.Mesh(
      zg('eye', () => new THREE.SphereGeometry(0.045, 6, 5)), M.eye);
    eye.position.set(s * 0.12, 0.62, 0.88);
    g.add(eye);
    const eye2 = new THREE.Mesh(
      zg('eye2', () => new THREE.SphereGeometry(0.028, 5, 4)), M.eye);
    eye2.position.set(s * 0.19, 0.57, 0.78);
    g.add(eye2);
  }

  // spine spikes down the back
  for (let i = 0; i < 5; i++) {
    const sp = new THREE.Mesh(
      zg('spike', () => new THREE.ConeGeometry(0.06, 0.28, 5)), M.dark);
    sp.scale.setScalar(1 - i * 0.09);
    sp.position.set(0, 0.88 - i * 0.03, 0.28 - i * 0.22);
    sp.rotation.x = -0.35 - i * 0.14;
    g.add(sp);
  }

  // the iconic shoulder scythes — bone arcs over the head
  for (const s of [-1, 1]) {
    const horn = buildHorn(1.95, 0.1, 2.45, M.bone);
    horn.position.set(s * 0.28, 0.72, -0.15);
    horn.rotation.z = -s * 0.35;               // splay outward
    g.add(horn);
  }

  // veined wings sweeping back over the abdomen
  const wings = [];
  for (const s of [-1, 1]) {
    const wg = new THREE.Group();
    const w = new THREE.Mesh(
      zg('wing', () => new THREE.PlaneGeometry(1.55, 0.95)), M.wing);
    w.scale.x = s;                              // mirror texture for left wing
    wg.add(w);
    wg.position.set(s * 0.14, 0.88, -0.3);
    wg.rotation.y = s * 0.95;                   // sweep backward/outward
    wg.rotation.z = -s * 0.55;                  // dihedral: tips up
    wg.userData.base = -s * 0.55;
    g.add(wg);
    wings.push(wg);
  }

  // legs — 4 animated, bone claws at the tips
  const legs = [];
  for (const s of [-1, 1]) for (const f of [0.3, -0.35]) {
    const leg = new THREE.Mesh(
      zg('leg', () => {
        const b = new THREE.BoxGeometry(0.09, 0.55, 0.09);
        b.translate(0, -0.275, 0);               // pivot at hip
        return b;
      }), M.dark);
    leg.position.set(s * 0.42, 0.56, f);
    const claw = new THREE.Mesh(
      zg('claw', () => {
        const c = new THREE.ConeGeometry(0.03, 0.14, 4);
        c.rotateX(Math.PI);                      // point down
        return c;
      }), M.bone);
    claw.position.set(0, -0.5, 0.04);
    leg.add(claw);
    g.add(leg);
    legs.push(leg);
  }

  // small forearm talons tucked under the scythes
  for (const s of [-1, 1]) {
    const arm = new THREE.Mesh(
      zg('arm', () => new THREE.BoxGeometry(0.06, 0.3, 0.06)), M.dark);
    arm.position.set(s * 0.24, 0.52, 0.5);
    arm.rotation.x = -0.6;
    const talon = new THREE.Mesh(
      zg('talon', () => {
        const c = new THREE.ConeGeometry(0.025, 0.18, 4);
        c.rotateX(Math.PI);
        return c;
      }), M.bone);
    talon.position.set(0, -0.2, 0.1);
    arm.add(talon);
    g.add(arm);
  }

  // tapering tail
  const tail = new THREE.Mesh(
    zg('tail', () => new THREE.ConeGeometry(0.1, 0.8, 5)), M.dark);
  tail.rotation.x = -Math.PI / 2 - 0.35;
  tail.position.set(0, 0.6, -1.05);
  g.add(tail);

  g.scale.setScalar(scale);
  g.userData.legs = legs;
  g.userData.wings = wings;
  return g;
}

/* ---------- roach model — tanky ranged unit ---------- */
function buildRoachMesh() {
  const g = new THREE.Group();
  const bodyMat  = new THREE.MeshStandardMaterial({ color: 0x6a5230, roughness: 0.9 });
  const shellMat = new THREE.MeshStandardMaterial({ color: 0x40341c, roughness: 0.8 });
  const sacMat   = new THREE.MeshStandardMaterial({
    color: 0x7ab832, emissive: 0x4a7a10, emissiveIntensity: 0.7, roughness: 0.5,
  });
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xff8833 });

  // heavy abdomen
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.75, 12, 9), bodyMat);
  body.scale.set(1.05, 0.8, 1.4);
  body.position.y = 0.85;
  body.userData.part = 'body';
  g.add(body);

  // armored plates
  for (const z of [-0.25, 0.35]) {
    const plate = new THREE.Mesh(new THREE.SphereGeometry(0.6, 10, 6), shellMat);
    plate.scale.set(1.1, 0.5, 0.7);
    plate.position.set(0, 1.15, z);
    g.add(plate);
  }

  // glowing acid sacs on the back
  for (const s of [-1, 1]) {
    const sac = new THREE.Mesh(new THREE.SphereGeometry(0.22, 7, 6), sacMat);
    sac.position.set(s * 0.45, 1.1, -0.45);
    g.add(sac);
  }

  // head low and forward + mandibles
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.3, 8, 7), bodyMat);
  head.position.set(0, 0.62, 0.95);
  head.userData.part = 'head';
  g.add(head);
  for (const s of [-1, 1]) {
    const mand = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.45, 5), shellMat);
    mand.rotation.x = Math.PI / 2 - 0.3;
    mand.rotation.z = -s * 0.5;
    mand.position.set(s * 0.18, 0.55, 1.15);
    mand.userData.part = 'head';
    g.add(mand);
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 5), eyeMat);
    eye.position.set(s * 0.16, 0.74, 1.05);
    g.add(eye);
  }

  // 4 thick legs + 2 scythe arms
  const legs = [];
  for (const s of [-1, 1]) for (const f of [0.5, -0.5]) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.7, 0.14), shellMat);
    leg.geometry.translate(0, -0.35, 0);
    leg.position.set(s * 0.62, 0.7, f);
    g.add(leg);
    legs.push(leg);
  }
  for (const s of [-1, 1]) {
    const scy = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.8, 4), shellMat);
    scy.position.set(s * 0.55, 0.9, 0.8);
    scy.rotation.x = -0.9; scy.rotation.z = -s * 0.35;
    g.add(scy);
  }
  g.userData.legs = legs;
  return g;
}

/* ---------- enemy ---------- */
function spawnEnemy(type, pos) {
  const roach = type === 'roach';
  const hunter = type === 'hunter';
  const mesh = roach ? buildRoachMesh() : buildZerglingMesh(hunter ? 1.5 : 1, hunter);
  mesh.position.copy(pos);
  const e = {
    mesh, hunter, roach,
    hp: roach ? 160 : hunter ? 120 : 34,
    speed: (roach ? 3.0 : hunter ? 4.2 : 5.6) * (0.9 + Math.random() * 0.25),
    radius: roach ? 1.2 : hunter ? 1.05 : 0.7,
    attackCd: 0,
    spitCd: 1.5 + Math.random() * 1.5,
    lungeT: 0,
    lungeFrom: null, lungeTo: null,
    dead: false, deathT: 0,
    weave: Math.random() * 10,
    screechT: 2 + Math.random() * 6,
  };
  mesh.userData.enemy = e;
  Enemies.scene.add(mesh);
  Enemies.list.push(e);
  Audio2.spawn(pos.distanceTo(Player.pos));
  return e;
}

/* ---------- spawner damage ---------- */
function damageSpawner(s, dmg) {
  if (s.dead) return;
  s.hp -= dmg;
  s.flash = 1;
  Audio2.hit();
  UI.hitmarker(false);
  bloodBurst(s.pos.clone().add(new THREE.Vector3(0, 0.8, 0)), 5);
  if (s.hp <= 0) {
    s.dead = true;
    Audio2.kill(s.pos.distanceTo(Player.pos));
    Audio2.wave();
    // hive collapse: dim everything, tilt, sink, kill beacon
    s.ringMat.emissiveIntensity = 0.05;
    s.ringMat.color.setHex(0x1a1220);
    s.moundMat.color.setHex(0x241a2e);
    s.sacMat.emissiveIntensity = 0;
    s.sacMat.color.setHex(0x2a2030);
    s.glow.intensity = 0;
    s.beam.visible = false;
    s.mesh.rotation.z = 0.18;
    s.mesh.position.y = -0.4;
    for (let i = 0; i < 16; i++) {
      const m = new THREE.Mesh(_gibGeo, new THREE.MeshBasicMaterial({ color: 0x8a3ae0 }));
      m.position.copy(s.pos); m.position.y = 0.8;
      Enemies.scene.add(m);
      Enemies.gibs.push({
        m, ttl: 1.2, t: 0,
        vx: (Math.random() - .5) * 9, vy: 2 + Math.random() * 6, vz: (Math.random() - .5) * 9,
        rs: (Math.random() - .5) * 14,
      });
    }
    const left = World.spawners.filter(x => !x.dead).length;
    UI.waveBanner(left ? `SPAWN-HIVE DESTROYED — ${left} LEFT` : 'ALL HIVES DOWN — CLEAR THE SWARM');
  }
}

function updateSpawners(dt) {
  for (const s of World.spawners) {
    if (s.dead) continue;
    s.flash = Math.max(0, s.flash - dt * 4);
    s.ringMat.emissiveIntensity = 0.9 + Math.sin(Game.time * 3 + s.pos.x) * 0.25 + s.flash * 1.6;
    s.sacMat.emissiveIntensity = 0.6 + Math.sin(Game.time * 2.2 + s.pos.z) * 0.25 + s.flash * 1.2;
    s.ring.rotation.z += dt * 0.6;
  }
}

/* ---------- roach acid spit ---------- */
const _spitGeo = new THREE.SphereGeometry(0.17, 8, 6);
const _spitMat = new THREE.MeshBasicMaterial({ color: 0x8aff30 });
function spitAcid(e) {
  const m = new THREE.Mesh(_spitGeo, _spitMat);
  const from = e.mesh.position.clone(); from.y = 1.3;
  m.position.copy(from);
  // aim at whatever the roach is hunting — player or marine
  const t = (e.tgtAlly && !e.tgtAlly.dead) ? e.tgtAlly.pos : Player.pos;
  const target = new THREE.Vector3(t.x, t.y + 1.3, t.z);
  const vel = target.sub(from).normalize().multiplyScalar(17);
  Enemies.scene.add(m);
  Enemies.spits.push({ m, vel, t: 0 });
  Audio2.spit(e.mesh.position.distanceTo(Player.pos));
}
function updateSpits(dt, onPlayerHit) {
  for (const s of Enemies.spits) {
    s.t += dt;
    s.vel.y -= 2.5 * dt;                          // slight arc
    s.m.position.addScaledVector(s.vel, dt);
    // acid can splatter the player or any living marine
    const check = (vx, vz, vy) =>
      Math.hypot(s.m.position.x - vx, s.m.position.z - vz) < 0.9 &&
      Math.abs(s.m.position.y - vy) < 1.2;
    if (check(Player.pos.x, Player.pos.z, Player.pos.y + 1.3)) {
      onPlayerHit(14, s.m.position);
      s.done = true;
    } else {
      for (const a of Allies.list) {
        if (!a.dead && check(a.pos.x, a.pos.z, 1.3)) {
          damageAlly(a, 14, s.m.position);
          s.done = true;
          break;
        }
      }
    }
    if (s.m.position.y < 0 || s.t > 3.5) {
      // green splash
      for (let i = 0; i < 5; i++) {
        const p = new THREE.Mesh(_bloodGeo, new THREE.MeshBasicMaterial({ color: 0x6ac020 }));
        p.position.copy(s.m.position);
        Enemies.scene.add(p);
        Enemies.gibs.push({
          m: p, ttl: 0.35, t: 0,
          vx: (Math.random() - .5) * 3, vy: Math.random() * 2, vz: (Math.random() - .5) * 3, rs: 0,
        });
      }
      s.done = true;
    }
    if (s.done) Enemies.scene.remove(s.m);
  }
  Enemies.spits = Enemies.spits.filter(s => !s.done);
}

function damageEnemy(e, dmg, headshot, byPlayer) {
  if (e.dead) return;
  e.hp -= dmg;
  bloodBurst(e.mesh.position.clone().add(new THREE.Vector3(0, 0.6, 0)), headshot ? 10 : 6);
  if (e.hp <= 0) {
    e.dead = true;
    e.deathT = 0;
    Enemies.kills++;
    if (byPlayer && !e.roach) {          // lings & hunters count toward command
      Player.kills++;
      if (!Game.leader && Player.kills >= PROMOTE_KILLS) promoteToLeader();
    }
    Audio2.kill(e.mesh.position.distanceTo(Player.pos));
    gibBurst(e.mesh.position, e.hunter);
    maybeDrop(e.mesh.position.clone());
    UI.hitmarker(true);
  } else {
    Audio2.hit();
    UI.hitmarker(false);
    // enrage briefly
    e.speed *= 1.04;
  }
}

/* ---------- particles ---------- */
const _gibGeo = new THREE.BoxGeometry(0.09, 0.09, 0.09);
const _gibMat = new THREE.MeshBasicMaterial({ color: 0xa02010 });
const _bloodGeo = new THREE.SphereGeometry(0.05, 5, 4);
const _bloodMat = new THREE.MeshBasicMaterial({ color: 0xc03018 });

function gibBurst(pos, big) {
  const n = big ? 14 : 8;
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(_gibGeo, _gibMat);
    m.position.copy(pos); m.position.y += 0.5;
    Enemies.gibs.push({
      m, ttl: 0.9 + Math.random() * 0.5, t: 0,
      vx: (Math.random() - .5) * 6, vy: 2 + Math.random() * 4, vz: (Math.random() - .5) * 6,
      rs: (Math.random() - .5) * 12,
    });
    Enemies.scene.add(m);
  }
}
function bloodBurst(pos, n) {
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(_bloodGeo, _bloodMat);
    m.position.copy(pos);
    Enemies.gibs.push({
      m, ttl: 0.4 + Math.random() * 0.3, t: 0,
      vx: (Math.random() - .5) * 3, vy: 1 + Math.random() * 2, vz: (Math.random() - .5) * 3,
      rs: 0,
    });
    Enemies.scene.add(m);
  }
}
function updateGibs(dt) {
  for (const g of Enemies.gibs) {
    g.t += dt;
    g.vy -= 14 * dt;
    g.m.position.x += g.vx * dt;
    g.m.position.y += g.vy * dt;
    g.m.position.z += g.vz * dt;
    if (g.m.position.y < 0.05) { g.m.position.y = 0.05; g.vy *= -0.3; g.vx *= 0.6; g.vz *= 0.6; }
    g.m.rotation.x += g.rs * dt; g.m.rotation.z += g.rs * dt;
    if (g.t > g.ttl) { Enemies.scene.remove(g.m); g.done = true; }
  }
  Enemies.gibs = Enemies.gibs.filter(g => !g.done);
}

/* ---------- pickups ---------- */
const _ammoGeo = new THREE.BoxGeometry(0.35, 0.35, 0.35);
const _ammoMat = new THREE.MeshStandardMaterial({ color: 0x2266aa, emissive: 0x2a8ae0, emissiveIntensity: 0.9 });
const _hpGeo = new THREE.BoxGeometry(0.32, 0.32, 0.32);
const _hpMat = new THREE.MeshStandardMaterial({ color: 0x22aa55, emissive: 0x2ae05a, emissiveIntensity: 0.9 });

function maybeDrop(pos) {
  const r = Math.random();
  if (r > 0.16) return;
  const type = r < 0.10 ? 'ammo' : 'health';
  const m = new THREE.Mesh(type === 'ammo' ? _ammoGeo : _hpGeo, type === 'ammo' ? _ammoMat : _hpMat);
  m.position.set(pos.x, 0.5, pos.z);
  Enemies.scene.add(m);
  Enemies.pickups.push({ m, type, t: 0 });
}
function updatePickups(dt) {
  for (const p of Enemies.pickups) {
    p.t += dt;
    p.m.rotation.y += dt * 2.4;
    p.m.position.y = 0.5 + Math.sin(p.t * 3) * 0.12;
    const d = Math.hypot(p.m.position.x - Player.pos.x, p.m.position.z - Player.pos.z);
    if (d < 1.6) {
      if (p.type === 'ammo') { Player.reserve = Math.min(480, Player.reserve + 40); UI.toast('+40 AMMO'); }
      else { Player.heal(30); UI.toast('+30 VITALS'); }
      Audio2.pickup();
      Enemies.scene.remove(p.m); p.done = true;
    }
    if (p.t > 25) { Enemies.scene.remove(p.m); p.done = true; }
  }
  Enemies.pickups = Enemies.pickups.filter(p => !p.done);
}

/* ---------- melee resolution — hit whichever victim is in reach ---------- */
function meleeHit(e, dmg) {
  const px = e.mesh.position.x, pz = e.mesh.position.z;
  let bd = Math.hypot(Player.pos.x - px, Player.pos.z - pz), victim = null;
  for (const a of Allies.list) {
    if (a.dead) continue;
    const d = Math.hypot(a.pos.x - px, a.pos.z - pz);
    if (d < bd) { bd = d; victim = a; }
  }
  if (bd >= 1.7) return;
  if (victim) damageAlly(victim, dmg, e.mesh.position);
  else damagePlayer(dmg, e.mesh.position);
}

/* ---------- per-frame enemy update ---------- */
const _v1 = new THREE.Vector3(), _v2 = new THREE.Vector3();

function updateEnemies(dt, onPlayerHit) {
  const p = Player.pos;
  for (const e of Enemies.list) {
    const m = e.mesh;

    if (e.dead) {
      e.deathT += dt;
      m.rotation.x = Math.min(Math.PI / 2, e.deathT * 6);   // keel over
      m.position.y = -e.deathT * 0.5;
      if (e.deathT > 1.1) { Enemies.scene.remove(m); e.gone = true; }
      continue;
    }

    e.attackCd -= dt;
    e.screechT -= dt;
    e.weave += dt * 6;

    // pick nearest victim — the player or a living marine
    let tp = p, tAlly = null;
    let dist = Math.hypot(p.x - m.position.x, p.z - m.position.z);
    for (const a of Allies.list) {
      if (a.dead) continue;
      const d = Math.hypot(a.pos.x - m.position.x, a.pos.z - m.position.z);
      if (d < dist) { dist = d; tp = a.pos; tAlly = a; }
    }
    e.tgtAlly = tAlly;

    const dx = tp.x - m.position.x, dz = tp.z - m.position.z;

    // face victim
    m.rotation.y = Math.atan2(dx, dz);

    if (e.lungeT > 0) {
      // mid-lunge: arc toward target
      e.lungeT += dt * 3.2;
      const k = Math.min(1, e.lungeT);
      m.position.lerpVectors(e.lungeFrom, e.lungeTo, k);
      m.position.y = Math.sin(k * Math.PI) * 1.1;
      if (k >= 1) {
        m.position.y = 0;
        e.lungeT = 0;
        meleeHit(e, e.hunter ? 18 : 9);
        e.attackCd = e.hunter ? 1.4 : 1.0;
      }
      continue;
    }

    if (dist < 2.3 && e.attackCd <= 0) {
      // start lunge
      e.lungeT = 0.001;
      e.lungeFrom = m.position.clone();
      e.lungeTo = tp.clone(); e.lungeTo.y = 0;
      Audio2.screech(dist);
      continue;
    }

    if (e.screechT <= 0 && dist < 30) {
      e.screechT = 3 + Math.random() * 7;
      Audio2.screech(dist);
    }

    const sd = Math.max(dist, 0.001);
    let mx = dx / sd, mz = dz / sd;
    let sp = e.speed;
    if (e.roach) {
      // roach: hold at range, spit acid, back off if player closes in, bite if cornered
      e.spitCd -= dt;
      if (dist < 2.8 && e.attackCd <= 0) {
        e.attackCd = 1.5;
        meleeHit(e, 16);
        Audio2.screech(dist);
      }
      if (e.spitCd <= 0 && dist > 4 && dist < 30) {
        spitAcid(e);
        e.spitCd = 2.4 + Math.random() * 1.2;
      }
      if (dist < 8) { mx = -mx; mz = -mz; sp *= 0.7; }          // back away
      else if (dist < 14) { const sx = -mz, sz = mx; mx = sx; mz = sz; sp *= 0.5; } // strafe
      else {
        const wob = Math.sin(e.weave) * 0.4;
        const px = -mz * wob, pz = mx * wob;
        mx += px; mz += pz;
      }
    } else {
      // zergling/hunter: sinus weave chase
      const wob = Math.sin(e.weave) * Math.min(1, dist / 12) * 0.7;
      const px = -mz * wob, pz = mx * wob;
      mx += px; mz += pz;
      sp *= dist < 6 ? 1.15 : 1;
    }
    const ml = Math.hypot(mx, mz) || 1;
    let nx = m.position.x + mx / ml * sp * dt;
    let nz = m.position.z + mz / ml * sp * dt;
    const res = worldCollide(nx, nz, e.radius);
    m.position.x = res.x; m.position.z = res.z;

    // separation
    for (const o of Enemies.list) {
      if (o === e || o.dead) continue;
      const ox = m.position.x - o.mesh.position.x, oz = m.position.z - o.mesh.position.z;
      const od = Math.hypot(ox, oz), min = e.radius + o.radius;
      if (od > 0 && od < min) {
        m.position.x += ox / od * (min - od) * 0.4;
        m.position.z += oz / od * (min - od) * 0.4;
      }
    }

    // run animation — legs cycle, body bobs
    const legs = m.userData.legs;
    if (legs)
      for (let i = 0; i < legs.length; i++)
        legs[i].rotation.x = Math.sin(e.animT + i * Math.PI) * 0.9 * msp;
    const wings = m.userData.wings;
    if (wings) {
      const flap = Math.sin(e.animT * 9) * 0.22 * Math.min(1, msp + 0.15);
      for (let i = 0; i < wings.length; i++)
        wings[i].rotation.z = wings[i].userData.base - (i === 0 ? -flap : flap);
    }
    m.position.y = Math.abs(Math.sin(e.animT)) * 0.09;
  }
  Enemies.list = Enemies.list.filter(e => !e.gone);
}

/* ---------- wave manager — endless pressure until hives die ---------- */
const Waves = {
  wave: 0,
  t: 0,
  spawnT: 0,

  alive() { return Enemies.list.filter(e => !e.dead).length; },
  hivesLeft() { return World.spawners.filter(s => !s.dead).length; },

  reset() {
    this.wave = 1;
    this.t = 0;
    this.spawnT = 1.2;
    UI.waveBanner('DESTROY THE 4 SPAWN-HIVES');
    Audio2.wave();
  },

  pickType() {
    const r = Math.random();
    if (this.wave >= 2 && r < 0.14 + this.wave * 0.012) return 'roach';
    if (this.wave >= 4 && r < 0.30) return 'hunter';
    return 'zergling';
  },

  update(dt) {
    const hives = World.spawners.filter(s => !s.dead);

    // all hives down → victory once the field is clear
    if (!hives.length) {
      if (this.alive() === 0 && Game.running) Game.victory();
      return;
    }

    // threat level ramps every 32s
    this.t += dt;
    if (this.t > 32) {
      this.t = 0;
      this.wave++;
      UI.waveBanner(`WAVE ${this.wave} — THE SWARM SURGES`);
      Audio2.wave();
    }

    this.spawnT -= dt;
    if (this.spawnT <= 0) {
      const cap = 14 + this.wave * 6;                 // swarm cap grows with threat
      let n = this.alive();
      if (n < cap) {
        this.spawnT = Math.max(0.45, 1.6 - this.wave * 0.12);
        const burst = 2 + Math.floor(this.wave / 2);  // lings pour out of EVERY hive
        for (const s of hives)
          for (let i = 0; i < burst && n < cap; i++, n++) {
            const pos = s.pos.clone();
            pos.x += (Math.random() - .5) * 4;
            pos.z += (Math.random() - .5) * 4;
            spawnEnemy(this.pickType(), pos);
          }
      } else {
        this.spawnT = 0.4;
      }
    }
  },
};

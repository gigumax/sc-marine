/* ============================================================
   main.js — bootstrap, HUD, gamepad, radar, main loop
   ============================================================ */

const $id = id => document.getElementById(id);

const Game = {
  running: false,
  paused: false,
  won: false,
  leader: false,                        // you command the squad after 50 kills
  scene: null, renderer: null, cam: null,
  time: 0,
};

/* ==================== UI helpers ==================== */
const UI = {
  toastTimer: null,
  toast(msg) {
    const t = $id('toast');
    t.textContent = msg;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => t.textContent = '', 1600);
  },
  waveBanner(text) {
    const b = $id('wave-banner');
    b.textContent = text;
    b.classList.remove('hidden');
    clearTimeout(this._bt);
    this._bt = setTimeout(() => b.classList.add('hidden'), 2200);
  },
  hitmarker(kill) {
    const h = $id('hitmarker');
    h.classList.toggle('kill', kill);
    h.classList.add('on');
    clearTimeout(this._ht);
    this._ht = setTimeout(() => h.classList.remove('on'), 110);
  },
  damageFlash() {
    const v = $id('vignette');
    v.style.opacity = 1;
    clearTimeout(this._vt);
    this._vt = setTimeout(() => v.style.opacity = Player.hp < 30 ? 0.5 : 0, 130);
  },
  updateHud() {
    const hpFrac = Player.hp / Player.maxHp;
    const fill = $id('hp-fill');
    fill.style.width = (hpFrac * 100) + '%';
    fill.className = hpFrac > 0.55 ? '' : hpFrac > 0.28 ? 'warn' : 'crit';
    $id('hp-num').textContent = Math.ceil(Player.hp);
    $id('suit-warn').classList.toggle('hidden', Player.hp > 30);
    $id('vignette').style.opacity = Player.hp < 30 ? 0.45 : $id('vignette').style.opacity;

    $id('ammo-mag').textContent = Player.mag;
    $id('ammo-res').textContent = Player.reserve;
    $id('ammo').classList.toggle('low', Player.mag <= 8);
    $id('wave-num').textContent = 'WAVE ' + Math.max(1, Waves.wave);
    $id('score').textContent = 'KILLS ' + Enemies.kills;
    $id('hive-num').textContent = 'HIVES ' + Waves.hivesLeft() + '/4';
    $id('rank').textContent = Game.leader
      ? '★ SQUAD LEADER'
      : 'PVT · ' + Math.min(PROMOTE_KILLS, Player.kills) + '/' + PROMOTE_KILLS;
    updateSquadHud();
  },
};

/* ==================== radar ==================== */
function drawRadar() {
  const c = $id('radar').getContext('2d');
  const R = 85, RANGE = 55;
  c.clearRect(0, 0, 170, 170);
  // rings
  c.strokeStyle = 'rgba(80,160,255,.25)';
  for (const r of [28, 56, 84]) { c.beginPath(); c.arc(R, R, r, 0, 7); c.stroke(); }
  c.beginPath(); c.moveTo(R, 0); c.lineTo(R, 170); c.moveTo(0, R); c.lineTo(170, R); c.stroke();

  const px = Player.pos.x, pz = Player.pos.z;
  const rot = Player.yaw;                          // rotate so up = facing
  const plot = (wx, wz, color, s) => {
    let dx = wx - px, dz = wz - pz;
    const rx = dx * Math.cos(rot) - dz * Math.sin(rot);
    const rz = dx * Math.sin(rot) + dz * Math.cos(rot);
    let x = rx / RANGE * R, y = rz / RANGE * R;
    const d = Math.hypot(x, y);
    if (d > R - 6) { x *= (R - 6) / d; y *= (R - 6) / d; }
    c.fillStyle = color;
    c.fillRect(R + x - s / 2, R + y - s / 2, s, s);
  };

  for (const s of World.spawners) if (!s.dead) plot(s.pos.x, s.pos.z, 'rgba(180,70,255,.95)', 7);
  for (const e of Enemies.list) if (!e.dead)
    plot(e.mesh.position.x, e.mesh.position.z,
         e.roach ? '#7aff4a' : e.hunter ? '#ff8a3a' : '#ff4a3a',
         e.roach || e.hunter ? 5 : 3.5);
  for (const s of Enemies.spits) plot(s.m.position.x, s.m.position.z, '#b4ff5a', 3);
  for (const p of Enemies.pickups) plot(p.m.position.x, p.m.position.z, p.type === 'ammo' ? '#5ab4ff' : '#5aff8a', 3.5);
  for (const a of Allies.list) if (!a.dead) plot(a.pos.x, a.pos.z, a.accent, 4);

  // player arrow (center, pointing up)
  c.fillStyle = '#9fd0ff';
  c.beginPath(); c.moveTo(R, R - 7); c.lineTo(R - 5, R + 5); c.lineTo(R + 5, R + 5); c.closePath(); c.fill();
}

/* ==================== gamepad ==================== */
const Pad = { on: false, prev: {}, lx: 0, ly: 0, rx: 0, ry: 0 };

function pollPad(dt) {
  const gp = (navigator.getGamepads ? [...navigator.getGamepads()] : []).find(p => p && p.connected);
  const lbl = $id('pad-status');
  if (!gp) { if (Pad.on) { Pad.on = false; lbl.classList.remove('connected'); $id('pad-label').textContent = 'no pad'; } return; }
  if (!Pad.on) { Pad.on = true; lbl.classList.add('connected'); $id('pad-label').textContent = gp.id.slice(0, 24); }

  const dz = v => Math.abs(v) < 0.16 ? 0 : v;
  Pad.lx = dz(gp.axes[0] || 0); Pad.ly = dz(gp.axes[1] || 0);
  Pad.rx = dz(gp.axes[2] || 0); Pad.ry = dz(gp.axes[3] || 0);

  // right stick → look
  Player.yaw   -= Pad.rx * 2.6 * dt * (Player.aiming ? 0.55 : 1);
  Player.pitch -= Pad.ry * 2.0 * dt * (Player.aiming ? 0.55 : 1);
  Player.pitch = Math.max(-1.45, Math.min(1.45, Player.pitch));

  const btn = i => gp.buttons[i] && gp.buttons[i].pressed;
  const once = i => { const n = btn(i), w = Pad.prev[i]; Pad.prev[i] = n; return n && !w; };

  if (once(2)) startReload();                        // X
  if (once(0)) tryJump();                            // A
  if (once(9)) {                                     // Start
    if (Player.dead || Game.won) restart();
    else if (!Game.running) startGame();
  }
  return { moveX: Pad.lx, moveZ: Pad.ly, sprint: btn(10), fire: btn(7), aim: btn(6) };
}

/* ==================== pointer lock ==================== */
const canvasClick = () => {
  if (Game.running && !Player.dead && !document.pointerLockElement && !Pad.on) {
    Game.renderer.domElement.requestPointerLock();
  }
};

/* ==================== HUD lifecycle ==================== */
function startGame() {
  $id('startscreen').classList.add('hidden');
  $id('gameover').classList.add('hidden');
  $id('hud').classList.remove('hidden');
  Game.running = true;
  Game.paused = false;
  Game.won = false; Game.leader = false;
  Game.time = 0;
  Player.kills = 0;
  Waves.reset();
  spawnAllies();
  canvasClick();
}
function restart() {
  // clear entities
  for (const e of Enemies.list) Enemies.scene.remove(e.mesh);
  for (const g of Enemies.gibs) Enemies.scene.remove(g.m);
  for (const p of Enemies.pickups) Enemies.scene.remove(p.m);
  for (const s of Enemies.spits) Enemies.scene.remove(s.m);
  for (const t of Player.tracers) Enemies.scene.remove(t.m);
  Enemies.list = []; Enemies.gibs = []; Enemies.pickups = []; Enemies.spits = []; Player.tracers = [];
  // restore spawn-hives
  for (const s of World.spawners) {
    s.dead = false; s.hp = s.maxHp; s.flash = 0;
    s.ringMat.emissiveIntensity = 1.1; s.ringMat.color.setHex(0x4a1a70);
    s.moundMat.color.setHex(0x3a1a50);
    s.sacMat.emissiveIntensity = 0.8; s.sacMat.color.setHex(0x6a2aa0);
    s.glow.intensity = 0.9; s.beam.visible = true;
    s.mesh.rotation.z = 0; s.mesh.position.y = 0;
  }
  Enemies.kills = 0;
  Player.pos.set(0, 0, 0); Player.vel.set(0, 0, 0);
  Player.hp = 100; Player.mag = 32; Player.reserve = 320;
  Player.dead = false; Player.reloading = false;
  Player.firing = false; Player.firingMouse = false; Player.aiming = false; Player.aimingMouse = false;
  Player.yaw = Math.PI; Player.pitch = 0;
  Waves.wave = 0; Waves.t = 0; Waves.spawnT = 1.2;
  Game.won = false; Game.time = 0; Game.leader = false;
  Player.kills = 0;
  $id('gameover').classList.add('hidden');
  $id('victory').classList.add('hidden');
  $id('hud').classList.remove('hidden');
  Game.running = true;
  Waves.reset();
  spawnAllies();
  canvasClick();
}
Game.gameOver = function () {
  Game.running = false;
  Audio2.over();
  document.exitPointerLock && document.exitPointerLock();
  $id('death-stats').innerHTML =
    `Hives destroyed: <b>${4 - Waves.hivesLeft()}/4</b><br>` +
    `Waves survived: <b>${Waves.wave}</b><br>Zerg killed: <b>${Enemies.kills}</b>`;
  $id('gameover').classList.remove('hidden');
};
Game.victory = function () {
  Game.running = false;
  Game.won = true;
  Audio2.pickup(); setTimeout(() => Audio2.wave(), 300);
  document.exitPointerLock && document.exitPointerLock();
  const mins = Math.floor(Game.time / 60), secs = Math.floor(Game.time % 60);
  $id('win-stats').innerHTML =
    `All spawn-hives destroyed.<br>` +
    `Time: <b>${mins}:${String(secs).padStart(2, '0')}</b><br>Zerg killed: <b>${Enemies.kills}</b>`;
  $id('victory').classList.remove('hidden');
};

/* ==================== boot ==================== */
window.addEventListener('load', () => {
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  $id('app').appendChild(renderer.domElement);
  Game.renderer = renderer;

  const scene = new THREE.Scene();
  Game.scene = scene;
  Enemies.scene = scene;

  const cam = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.08, 500);
  scene.add(cam);
  Game.cam = cam;

  buildWorld(scene);
  initPlayer(cam);

  renderer.domElement.addEventListener('click', canvasClick);
  document.addEventListener('pointerlockchange', () => {
    Game.paused = Game.running && !document.pointerLockElement && !Pad.on && !Player.dead;
    $id('paused').classList.toggle('hidden', !Game.paused);
  });
  $id('paused').addEventListener('click', canvasClick);
  $id('btn-start').onclick = startGame;
  $id('btn-retry').onclick = restart;
  $id('btn-vretry').onclick = restart;
  window.addEventListener('resize', () => {
    renderer.setSize(innerWidth, innerHeight);
    cam.aspect = innerWidth / innerHeight;
    cam.updateProjectionMatrix();
  });
  // Enter also starts
  window.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !Game.running && (Player.dead || Game.won)) restart();
    else if (e.key === 'Enter' && !Game.running) startGame();
  });

  let last = performance.now();
  function loop(t) {
    requestAnimationFrame(loop);
    const dt = Math.min(0.05, (t - last) / 1000);
    last = t;

    if (Game.running && !Game.paused && !Player.dead) {
      Game.time += dt;
      const pad = pollPad(dt) || { moveX: 0, moveZ: 0, sprint: false, fire: false, aim: false };
      Player.firing = Player.firingMouse || pad.fire;
      Player.aiming = Player.aimingMouse || pad.aim;
      // merge keyboard
      const kx = (KEYS['d'] ? 1 : 0) - (KEYS['a'] ? 1 : 0) + pad.moveX;
      const kz = (KEYS['s'] ? 1 : 0) - (KEYS['w'] ? 1 : 0) + pad.moveZ;
      const sprint = KEYS['shift'] || pad.sprint;
      movePlayer(dt, Math.max(-1, Math.min(1, kx)), Math.max(-1, Math.min(1, kz)), sprint);

      updatePlayer(dt);
      updateEnemies(dt, damagePlayer);
      updateAllies(dt);
      updateSpits(dt, damagePlayer);
      updateSpawners(dt);
      updateGibs(dt);
      updatePickups(dt);
      Waves.update(dt);
      UI.updateHud();
      drawRadar();
    } else if (Player.dead) {
      // death cam: slump to ground
      Player.cam.position.y += (0.35 - Player.cam.position.y) * dt * 3;
      Player.cam.rotation.z += (0.5 - Player.cam.rotation.z) * dt * 2;
      updateGibs(dt);
    } else {
      pollPad(dt);
    }

    renderer.render(scene, cam);
  }
  requestAnimationFrame(loop);
});
